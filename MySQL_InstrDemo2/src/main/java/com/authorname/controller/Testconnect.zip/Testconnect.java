package com.javatpoint.connect;

import java.util.*;
import java.sql.*;

import com.authorname.model.Partition;
import com.authorname.model.JdbcPartModel;

public class Testconnect {
   public static final String SERVER="localhost", DB="instr_collection", LOGIN="root", PASSWORD="lpf6lmsql", VIEWS="/javatpoint";
      
   public static void main(String args[]) {

        int id=0;
	// procedure which create the Jdbc object, get action to do and perform index (Connect to db), create new Partition In Java,   }
	JdbcPartModel jdbcmdl = new JdbcPartModel(SERVER, DB, LOGIN, PASSWORD);

        String partname="be bop";
	String authorname="Hawkins Coleman";
	String instrname="trumpet";
	Partition part = new Partition(1,partname,1,1);

	// call the particular method connect of jdbcmdl
        try {
           jdbcmdl.connect();
		// to see if there is a matching for Partition name in the DB
	   List<Partition> reslist = jdbcmdl.searchPart_name(part.getName(), authorname);
	   for (Partition partfound : reslist) {
              System.out.println("found a record for part: "+partfound.getName()+ "with ID: "+partfound.getId());
	   }
	  
	}
	catch (SQLException e) {
          System.out.println("Erreur de connection a la base de donnees ou de lecture");
	}
  }// end main
}// end class





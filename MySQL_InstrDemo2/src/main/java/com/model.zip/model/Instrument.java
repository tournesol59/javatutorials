package com.authorname.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Instrument extends RecordObj {

	private int id;
	private String name;
	private int playpart;
	private String place;

	public Instrument(int instr_id, String instr_name, int instr_playpart, String instr_place) {
            super();
	    this.id=instr_id;
	    this.name=instr_name;
	    this.playpart=instr_playpart;
	    this.place=instr_place;
	}

	public int getId() {
            return this.id;
	}

	public void setId(int instr_id) {
            this.id=instr_id;
	}

	public String getName() {
	    return this.name;
	}

	public void setName(String instr_name) {
            this.name=instr_name;
	}

	public int getPlayPart() {
	    return this.playpart;
	}

	public void setPlayPart(int instr_playpart) {
            this.playpart=instr_playpart;
	}

	public String getPlace() {
	    return this.place;
	}

	public void setPlace(String instr_place) {
            this.place=instr_place;
	}

	//methods inherited from RecordObj
   public Date getDate() {
      return date;
   }

   public void setDate(Date adate) {
     this.date = adate;
   }

   public String getMessage() {
      return message;
   }

   public void setMessage(String message) {
      this.message = message;
   }
	
};


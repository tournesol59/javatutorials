package com.authorname.model;

import java.util.Date;

public class Partition extends RecordObj {

	private int id;
	private String name;
	private int instr;
	private int auth;

	public Partition(int part_id, String part_name, int part_instr, int part_auth) {
            super();
	    this.id=part_id;
	    this.name=part_name;
	    this.instr=part_instr;
	    this.auth=part_auth;
	}

	public int getId() {
            return id;
	}

	public void setId(int part_id) {
            this.id=part_id;
	}

	public String getName() {
	    return name;
	}

	public void setName(String part_name) {
            this.name=part_name;
	}

	public int getInstr() {
	    return instr;
	}

	public void setInstr(int part_instr) {
            this.instr=part_instr;
	}

	public int getAuth() {
	    return auth;
	}

	public void setAuth(int part_auth) {
            this.auth=part_auth;
	}
	
   public Date getDate() {
      return date;
   }

   public void setDate(Date adate) {
     this.date = adate;
   }

   public String getMessage() {
      return message;
   }

   public void setMessage(String message) {
      this.message = message;
   }

};


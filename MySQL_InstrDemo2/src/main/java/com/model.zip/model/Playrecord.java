package com.authorname.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;

public class Playrecord extends RecordObj {

	private int id;
	private String name;
	private String addr_file;
	private int muse;
        private String datestring;

	public Playrecord(int play_id, String play_name, String play_addr_file, int play_muse, String play_datestring) {
            super();
	    this.id=play_id;
	    this.name=play_name;
	    this.addr_file = play_addr_file;
	    this.muse = play_muse;
	    this.datestring = play_datestring;  // then one will have to convert this
	}

	public int getId() {
            return id;
	}

	public void setId(int play_id) {
            this.id=play_id;
	}

	public String getName() {
	    return name;
	}

	public void setName(String play_name) {
            this.name=play_name;
	}
	
	public String getAddrFile() {
	    return addr_file;
	}

	public void setAddrFile(String play_addr_file) {
            this.name=play_addr_file;
	}

	public int getMuse() {
	    return muse;
	}

	public void setMuse(int play_muse) {
            this.muse=play_muse;
	}

     public void parseDateFromString() {
     // fred: the objective is to use Date as type in bean property, but we need..
     try {
       SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
       this.date = formatter.parse(this.datestring);
       // if general format was used:
     //String formattedDate = formatter.format(dateStr);
     //System.out.println("yyyy-MM-dd date is ==>"+formattedDate);
     //Date date1 = formatter.parse(formattedDate);
     }
     catch (Exception e) {
       System.out.println("User constructor method parseDateFromString failed");
     }

   }

	// fields inherited
   public Date getDate() {
      return date;
   }

   public void setDate(Date adate) {
     this.date = adate;
   }

   public String getMessage() {
      return message;
   }

   public void setMessage(String message) {
      this.message = message;
   }


  }
